Name: Yash Avinash Patole
Course: CS541
Title: Assignment 0
CWID: 10460520

twin_prime.py is a python file which will take any number and generates an output which maximum twin_prime between 1 and the input provided .
grayscale.py is a python file where you submit any jpeg document where it get converted into grayscale by converting each pixel 

summary.py is a python file which shows mean, min, max and std of a particular state cases.

Thank you!!